import numpy as np
import os.path
import scipy.misc
import tensorflow as tf
import time

import dm_arch
import dm_input
import dm_utils

FLAGS = tf.app.flags.FLAGS

